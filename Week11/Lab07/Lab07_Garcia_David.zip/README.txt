# Lab 07: Shipping Boxes

* Author: David Garcia
* Class: CPSC121 Section 002
* Semester: Spring 2023

## Overview
We created a box starting with a UML diagram, 
from there we create 2 boxes with set dimensions and calculate their surfaceArea and area.
The last part of the lab we create 5 boxes with random dimensions and compare them so as to 
see which one is the largest using an arraylist and a for each as well as a standard for loop.

## Compiling and Using
In order to use we just run the program and the code generates all necessary parameters.

## Discussion
I was having isues implementing the arraylist since we just got introduced to it. 
I ran in to an issue where I looped and printed each iteration of my boxes on top of another
but that was an easy fix as I just had to move some code around.

## Testing
Testing, it was a matter of running multiple times and checking that the box with the largest dimensions was 
picked and printed out on every attempt of running the program.

----------