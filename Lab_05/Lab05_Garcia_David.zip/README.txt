# Lab 05: Going Loopy

* Author: David Garcia
* Class: CPSC121 Section 002
* Semester: Spring 2023

## Overview
This lab is all about utilizing loops in order to
read a string and output it backwards, to taking a number and 
outputting if it equals 0 when using modulo division as well as outputting about
a multiplication table and a guessing game with multiple attempts.

## Compiling and Using
In order to use you have run the program, 
there's two applications which will prompt you for input.
Once you input the necessary data the program will execute and compare your integer 
to see if you guessed right or a string to deconstruct it and output it backwards.

## Discussion
For the going loopy portion, I for whatever reason was trying to do things without the inclusion of an if
statement. I was attempting and came to the conclusion that the easiest way to do it was to include one though
I didn't think I was allowed to use it for that excercise. After the class demonstration I felt rather silly as
if I had gone that route I could have potentially finished or may have had a succesful attempt before watching
the demonstration at the end.

## Testing
Testing was done by inputing the necessary data like a string or integer.
If the integer is out of bounds we should get a message which asks the
user to input the necessary data within set parameter.

----------