# Lab 02: Time Conversion

* Author: David Garcia
* Class: CPSC121 Section 00#
* Semester: Spring 2023

## Overview
These are my versions of my time conversion programs
One program takes in 3 inputs from the user in order to convert the total time in to seconds.
The second program converts a total set of seconds in to my hours, minutes and seconds with a fractional 
calculation as well at the end.

## Compiling and Using
In order to compile the user just hits run and then is prompted for multiple integer inputs.

## Discussion
I was having an issue with my arithmetic calculations. I was trying to divide my integers
for my total seconds but because I was dividing first I was losing my remainder which is what I needed.
I ended just having to use my modulo in order to get my secondas answer.

## Testing
I tested by first using a calculator in order to see what equations I tought I needed
I then proceeded to code in and input the same answers in order to match what I got Onemy calculator.


----------