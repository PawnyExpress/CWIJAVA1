# Lab 06: A Game of Chance

* Author: David Garcia
* Class: CPSC121 Section 002
* Semester: Spring 2023

## Overview
We are creating a set of classes to roll dice and the play against a computer
so that we can tally up our scores as well as see if we want to keep playing vs the computer.

## Compiling and Using
To use we just hit run and the game begins.

## Discussion
I was having issues at the beginning by declaring and using the given class,
that was followed with some logic errors at the end where I forgot to add my counts.

## Testing
Testing I would run my program and ensured any input other than y would exit out as well
as whenever I would lose, win or tie I would get the right output for the result.

----------