# Lab 4: Conditionals

* Author: David Garcia
* Class: CPSC121 Section 002
* Semester: Spring 2023

## Overview
Run the code, the program will prompt the user for integer values so 
we can take the imput and output the appropriate result.

## Compiling and Using
Run the code, you will be prompted for integer values on the first 3 programs
and for the last you'll beproviding boolean values as your input.

## Discussion
The first three problems were standard if-else statements which were not too much of an issue.
Nesting another if statement had me rewrite part of the code as I was outputing the wrong answer
on my first couple of attempts. On problem 4 the ternary operator was also a small problem as I have never used it and
had a similar issue where I was outputing the wrong answer.

## Testing
Testing wise I input the necessary values needed to be within range of the desired output.
Same for my boolean inputs. Made sure my output was same as the table I had in order asses if correct or not.

----------